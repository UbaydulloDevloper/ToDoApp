package adapters

data class DateLevel(val  name:String,val image:Int)
